package library;

import java.io.*;
import javax.swing.JOptionPane;    // necessary directive to allow use of JOPtionPane from the API
import java.util.*;

// Release 1: 2008/11/27
// Release 4: 2009/07/14

public class GIO {
// Provide simple facilities for text I/O (standard input and output streams in dialogue boxes)
// P.D. Terry (p.terry@ru.ac.za)

  // Input routines

  public static String readString(String prompt) {
    String s = JOptionPane.showInputDialog(prompt);
    if (s == null) System.exit(1);
    return s;
  }

  public static String readString() {
    return readString("");
  }

  public static char readChar(String prompt) {
    while (true) {
      String input = readString(prompt + " (Character)");
      if (input.length() == 0)
        write("Bad Character format - try again");
      else
        return input.charAt(0);
    }
  }

  public static char readChar() {
    return readChar("");
  }

  public static boolean readBoolean(String prompt) {
    while (true) {
      String input = readString(prompt + " (Boolean)").trim();
      if (input.length() == 0)
        write("Bad Boolean format - try again");
      else {
        char ch = Character.toUpperCase(input.charAt(0));
        return ch == 'T' || ch == 'Y';
      }
    }
  }

  public static boolean readBoolean() {
    return readBoolean("");
  }

  public static int readInt(String prompt) {
    while (true) {
      String input = readString(prompt + " (Integer)");
      try {
        return Integer.parseInt(input);
      }
      catch (NumberFormatException e) {
        write("Bad numeric format - try again");
      }
    }
  }

  public static int readInt() {
    return readInt("");
  }

  public static short readShort(String prompt) {
    while (true) {
      String input = readString(prompt + " (Short)");
      try {
        return Short.parseShort(input);
      }
      catch (NumberFormatException e) {
        write("Bad numeric format - try again");
      }
    }
  }

  public static short readShort() {
    return readShort("");
  }

  public static long readLong(String prompt) {
    while (true) {
      String input = readString(prompt + " (Long)");
      try {
        return Long.parseLong(input);
      }
      catch (NumberFormatException e) {
        write("Bad numeric format - try again");
      }
    }
  }

  public static long readLong() {
    return readLong("");
  }

  public static float readFloat(String prompt) {
    while (true) {
      String input = readString(prompt + " (Float)");
      try {
        return Float.parseFloat(input);
      }
      catch (NumberFormatException e) {
        write("Bad numeric format - try again");
      }
    }
  }

  public static float readFloat() {
    return readFloat("");
  }

  public static double readDouble(String prompt) {
    while (true) {
      String input = readString(prompt + " (Double)");
      try {
        return Double.parseDouble(input);
      }
      catch (NumberFormatException e) {
        write("Bad numeric format - try again");
      }
    }
  }

  public static double readDouble() {
    return readDouble("");
  }

  // formatters

  public static String fixedRep(double d, int fractionDigits) {
    String fmt = "%1." + String.valueOf(Math.abs(fractionDigits)) + "f";
    return String.format(fmt, d);
  }

  public static String fixedRep(float f, int fractionDigits) {
    String fmt = "%1." + String.valueOf(Math.abs(fractionDigits)) + "f";
    return String.format(fmt, f);
  }

  public static String floatingRep(double d, int fractionDigits) {
    String fmt = "%1." + String.valueOf(Math.abs(fractionDigits)) + "E";
    return String.format(fmt, d);
  }

  public static String floatingRep(float f, int fractionDigits) {
    String fmt = "%1." + String.valueOf(Math.abs(fractionDigits)) + "E";
    return String.format(fmt, f);
  }

  // output routines

  public static void write(Object o) {
    JOptionPane.showMessageDialog(null, o);
  }

  // unlabelled

  public static void write(double d) {
    JOptionPane.showMessageDialog(null, d);
  }

  public static void write(int i) {
    JOptionPane.showMessageDialog(null, i);
  }

  public static void write(char c) {
    JOptionPane.showMessageDialog(null, c);
  }

  public static void write(long i) {
    JOptionPane.showMessageDialog(null, i);
  }

  public static void write(boolean b) {
    JOptionPane.showMessageDialog(null, b);
  }

  public static void writeFixed(double d, int fractionDigits) {
    JOptionPane.showMessageDialog(null, fixedRep(d, fractionDigits));
  }

  public static void writeFloating(double d, int fractionDigits) {
    JOptionPane.showMessageDialog(null, floatingRep(d, fractionDigits));
  }

  public static void write(float f) {
    JOptionPane.showMessageDialog(null, f);
  }

  public static void writeFixed(float d, int fractionDigits) {
    JOptionPane.showMessageDialog(null, fixedRep(d, fractionDigits));
  }

  public static void writeFloating(float d, int fractionDigits) {
    JOptionPane.showMessageDialog(null, floatingRep(d, fractionDigits));
  }

  // labelled

  public static void write(String label, Object o) {
    write(label + ": " + o);
  }

  public static void write(String label, double d) {
    write(label + ": " + d);
  }

  public static void write(String label, char c) {
    write(label + ": " + c);
  }

  public static void write(String label, int i) {
    write(label + ": " + i);
  }

  public static void write(String label, long i) {
    write(label + ": " + i);
  }

  public static void write(String label, boolean b) {
    write(label + ": " + b);
  }

  public static void writeFixed(String label, double d, int fractionDigits) {
    write(label + ": " + fixedRep(d, fractionDigits));
  }

  public static void writeFloating(String label, double d, int fractionDigits) {
    write(label + ": " + floatingRep(d, fractionDigits));
  }

  public static void write(String label, float f) {
    write(label + ": " + f);
  }

  public static void writeFixed(String label, float d, int fractionDigits) {
    write(label + ": " + fixedRep(d, fractionDigits));
  }

  public static void writeFloating(String label, float d, int fractionDigits) {
    write(label + ": " + floatingRep(d, fractionDigits));
  }

} // GIO

