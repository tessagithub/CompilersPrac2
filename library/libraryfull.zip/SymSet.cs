using System;
using System.IO;
using System.Text;
using System.Collections;

namespace Library {

  public class SymSet {   // revised 2016/10/06
  // Simple set class for integers 0 <= i <= max
  // P.D. Terry (p.terry@ru.ac.za)
  // copy of SymSet - for compatibility with the new Java version

    const int Default = 512;      // default set size

    BitArray bitSet;

    private int max(int a, int b) {
      if (a > b) return a; else return b;
    } // SymSet.max

    private int min(int a, int b) {
      if (a < b) return a; else return b;
    } // SymSet.max

    private SymSet(int size) {
      this.bitSet = new BitArray(size);
    } // SymSet.Constructor(size)

    public SymSet() : this(Default) {}
    // Empty set constructor

    public SymSet(SymSet old) {
    // Construct set from old
      this.bitSet = new BitArray(old.bitSet);
    } // SymSet.Constructor

    private SymSet(BitArray b) {
      this.bitSet = b;
    } // SymSet.Constructor

    public SymSet(params int[] members) {
    // Variable args constructor  SymSet(a)  SymSet(a,b) etc
      int m = 0;
      foreach (int i in members) if (i > m) m = i;
      this.bitSet = new BitArray(max(Default, m + 1));
      foreach (int i in members) this.bitSet[i] = true;
    } // SymSet.Constructor, initialised

    private SymSet Expand(SymSet old, int newSize) {
      SymSet expandedSet = old.Copy();
      if (newSize > old.bitSet.Length) expandedSet.bitSet.Length = newSize;
      return expandedSet;
    } // SymSet.Expand

    public object Clone() {
    // Value copy
      return new SymSet(this);
    } // SymSet.Clone

    public SymSet Copy() {
    // Value copy
      return new SymSet(this);
    } // SymSet.Copy

    public bool Equals(SymSet that) {
    // Value comparison - true if this and that sets contain same elements
      if (that == null) return false;
      int commonSize = max(this.bitSet.Length, that.bitSet.Length);
      SymSet one = Expand(this, commonSize);
      SymSet two = Expand(that, commonSize);
      for (int i = 0; i < commonSize; i++)  {
        if (one.bitSet[i] != two.bitSet[i]) return false;
      }
      return true;
    } // SymSet.Equals

    public void Incl(int i) {
    // Includes i in this set
      if (i >= 0) {
        if (i >= this.bitSet.Length) this.bitSet.Length = max(2 * this.bitSet.Length, i + 1);
        this.bitSet[i] = true;
      }
    } // SymSet.Incl

    public void Excl(int i) {
    // Excludes i from this set
      if (i >= 0 && i < this.bitSet.Length) this.bitSet[i] = false;
    } // SymSet.Excl

    public bool Contains(int i) {
    // Returns true if i is a member of this set
      return i >= 0 && i < this.bitSet.Length && this.bitSet[i];
    } // SymSet.Contains

    public bool Contains(SymSet that) {
    // Returns true if that set is a subset of this set
      return that.IsEmpty() || that.Difference(this).IsEmpty();
    } // SymSet.Contains

    public bool IsEmpty() {
    // Returns true if this set is empty
      for (int i = 0; i < this.bitSet.Length; i++)
        if (this.bitSet[i]) return false;
      return true;
    } // SymSet.isEmpty

    public bool IsFull() {
    // Returns true if this set is a universe set
      for (int i = 0; i < this.bitSet.Length; i++)
        if (!this.bitSet[i]) return false;
      return true;
    } // SymSet.isFull

    public bool IsFull(int max) {
    // Returns true if this set is a universe set
      for (int i = 0; i < max; i++)
        if (!this.bitSet[i]) return false;
      return true;
    } // SymSet.isFull

    public void Fill() {
    // Creates a full universe set for this set
      for (int i = 0; i < this.bitSet.Length; i++) this.bitSet[i] = true;
    } // SymSet.Fill

    public void Fill(int max) {
    // Creates a full universe set for this set
      for (int i = 0; i < max; i++) this.bitSet[i] = true;
    } // SymSet.Fill(max)

    public void Clear() {
    // Clear this set
      for (int i = 0; i < this.bitSet.Length; i++) this.bitSet[i] = false;
    } // SymSet.Clear

    public int Members() {
    // Returns number of members in this set
      int count = 0;
      for (int i = 0; i < this.bitSet.Length; i++) if (this.bitSet[i]) count++;
      return count;
    } // SymSet.Members

    public SymSet Union(SymSet that) {
    // Set union of this set and that set
      int commonSize = max(this.bitSet.Length, that.bitSet.Length);
      SymSet one = Expand(this, commonSize);
      SymSet two = Expand(that, commonSize);
      return new SymSet(one.bitSet.Or(two.bitSet));
    } // SymSet.Union

  /*
    public SymSet Difference(SymSet that) {
    // Set difference
      int commonSize = max(this.bitSet.Length, that.bitSet.Length);
      SymSet one = Expand(this, commonSize);
      SymSet two = Expand(that, commonSize);
      for (int i = 0; i < commonSize; i++) one.bitSet[i] = one.bitSet[i]  && ! two.bitSet[i];
      return one;
    } // SymSet.Difference
  */

    public SymSet Difference(SymSet that) {
    // Set difference of this set and that set
      int minSize = min(this.bitSet.Length, that.bitSet.Length);
      SymSet one = this.Copy();
      for (int i = 0; i < minSize; i++) one.bitSet[i] = one.bitSet[i]  && ! that.bitSet[i];
      return one;
    } // SymSet.Difference

  /*
    public SymSet Intersection(SymSet that) {
    // Set intersection
      int commonSize = max(this.bitSet.Length, that.bitSet.Length);
      SymSet one = Expand(this, commonSize);
      SymSet two = Expand(that, commonSize);
      return new SymSet(one.bitSet.And(two.bitSet));
    } // SymSet.intersection
  */

    public SymSet Intersection(SymSet that) {
    // Set intersection of this set and that set
      int minSize = min(this.bitSet.Length, that.bitSet.Length);
      SymSet one = new SymSet(minSize);
      for (int i = 0; i < minSize; i++) one.bitSet[i] = this.bitSet[i]  && that.bitSet[i];
      return one;
    } // SymSet.Intersection

    public SymSet SymDiff(SymSet that) {
    // Set symmetric difference of this set and that set
      int commonSize = max(this.bitSet.Length, that.bitSet.Length);
      SymSet one = Expand(this, commonSize);
      SymSet two = Expand(that, commonSize);
      return new SymSet(one.bitSet.Xor(two.bitSet));
    } // SymSet.SymDiff

    public SymSet Xor(SymSet that) {
    // Set symmetric difference of this set and that set
      int commonSize = max(this.bitSet.Length, that.bitSet.Length);
      SymSet one = Expand(this, commonSize);
      SymSet two = Expand(that, commonSize);
      return new SymSet(one.bitSet.Xor(two.bitSet));
    } // SymSet.Xor

    public void Properties () {
    // Simple diagostic for testing
      Console.WriteLine(this.bitSet.Length
              + "   " + this.Members()
              + "   " + this.ToString());
    } // SymSet.Properties

    public void Write() {
    // Simple display of this set on StdOut
      Console.Write(this);
    } // SymSet.Write

    public override string ToString() {
    // Returns string representation of this set as set of ints
      StringBuilder sb = new StringBuilder(1000);
      sb.Append('{');
      bool comma = false;
      for (int i = 0; i < this.bitSet.Length; i++)
        if (this.bitSet[i]) {
          if (comma) sb.Append(", "); comma = true;
          sb.Append(i.ToString());
        }
      sb.Append("}");
      return sb.ToString();
    } // SymSet.ToString

    public string ToCharSetString() {
    // Returns string representation of this set as set of chars
      StringBuilder sb = new StringBuilder(1000);
      sb.Append('{');
      bool comma = false;
      for (int i = 0; i < this.bitSet.Length; i++)
        if (this.bitSet[i]) {
          if (comma) sb.Append(", "); comma = true;
          switch (i) {
            case '\"' : sb.Append("'\"'");   break;
            case '\\' : sb.Append("'\\\\'"); break;
            case '\'' : sb.Append("'\\\''"); break;
            case '\a' : sb.Append("'\\a'");  break;
            case '\b' : sb.Append("'\\b'");  break;
            case '\f' : sb.Append("'\\f'");  break;
            case '\n' : sb.Append("'\\n'");  break;
            case '\r' : sb.Append("'\\r'");  break;
            case '\t' : sb.Append("'\\t'");  break;
            case '\v' : sb.Append("'\\v'");  break;
            default   : sb.Append("'" + ((char) i) + "'"); break;
          }
        }
      sb.Append("}");
      return sb.ToString();
    } // SymSet.ToCharSetString

  } // SymSet

} // namespace
