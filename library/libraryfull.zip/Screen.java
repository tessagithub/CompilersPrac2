package library;

import jcurses.system.*;

public class Screen {
// Simple screen addressed I/O like that in TurboPascal
// Built on the jcurses library
//   http://sourceforge.net/projects/javacurses/
//   (Alexei Chmelev)
    // The screen is addressed as (0,0) in the top left, with x increasing to the
    // right and y increasing downwards.  The limits are imposed by the size of
    // the DOS window in which the client program is run.
// P.D. Terry, Rhodes University, 2009

  private static CharColor defaultColors = new CharColor(CharColor.BLACK, CharColor.WHITE);
  private static CharColor currentColors = new CharColor(CharColor.BLACK, CharColor.WHITE);
  private static CharColor errorColors   = new CharColor(CharColor.RED, CharColor.WHITE);
  private static boolean stopOnErrors = true;
  private static String blanks = "                                                                                                                                 ";

  public static final short BLACK   = CharColor.BLACK;    // 0
  public static final short RED     = CharColor.RED;      // 1
  public static final short GREEN   = CharColor.GREEN;    // 2
  public static final short YELLOW  = CharColor.YELLOW;   // 3
  public static final short BLUE    = CharColor.BLUE;     // 4
  public static final short MAGENTA = CharColor.MAGENTA;  // 5
  public static final short CYAN    = CharColor.CYAN;     // 6
  public static final short WHITE   = CharColor.WHITE;    // 7

  private static boolean alreadyInitialized = false;

  public static void setColors(short backgroundColor, short foregroundColor) {
    currentColors = new CharColor(backgroundColor, foregroundColor);
  } // setColors

  public static void setBackgroundColor(short backgroundColor) {
    currentColors.setBackground(backgroundColor);
  } // setBackgroundColor

  public static void setForegroundColor(short foregroundColor) {
    currentColors.setForeground(foregroundColor);
  } // setColors

  public static short getBackgroundColor() {
    return currentColors.getBackground();
  } // getBackGround

  public static short getForegroundColor() {
    return currentColors.getForeground();
  } // getForegroundColor

  public static void invertColors() {
    currentColors = new CharColor(currentColors.getForeground(), currentColors.getBackground());
  } // invertColors

  public static int getScreenHeight() {
    return Toolkit.getScreenHeight();
  } // getScreenHeight

  public static int getScreenWidth() {
    return Toolkit.getScreenWidth();
  } // getScreenHeight

  private static class OnExit extends Thread { // clever way of installing termination routine

    public void run() {
      Toolkit.printString("Terminating Screen I/O cleanly - please hit ESC to exit", 0, 0, errorColors);
      int key;
      do {
        key = Toolkit.readCharacter().getCode();
      } while (key != KEY_ESCAPE);
      Toolkit.shutdown();
    } // run

  } // OnExit

  public static void init() {
    if (!alreadyInitialized) {
      if (getScreenWidth() < 10 || getScreenHeight() < 10) {
        System.err.println("Screen library does not work in the IDE - run from the command line");
        System.exit(1);
      }
      Runtime.getRuntime().addShutdownHook(new OnExit());
      Toolkit.clearScreen(defaultColors);
      alreadyInitialized = true;
    }
  } // init

  public static void init(boolean pauseOnExit) {
    if (!alreadyInitialized) {
      if (getScreenWidth() < 10 || getScreenHeight() < 10) {
        System.err.println("Screen library does not work in the IDE - run from the command line");
        System.exit(1);
      }
      if (pauseOnExit) Runtime.getRuntime().addShutdownHook(new OnExit());
      Toolkit.clearScreen(defaultColors);
      alreadyInitialized = true;
    }
  } // init

  public static void ignoreErrors() {
    stopOnErrors = false;
  } // ignoreErrors

  public static void trapErrors() {
    stopOnErrors = true;
  } // trapErrors

  public static void clearScreen() {
    if (!alreadyInitialized) init();
    Toolkit.clearScreen(defaultColors);
  } // clearScreen

  public static void clearScreen(short backgroundColor) {
    if (!alreadyInitialized) init();
    Toolkit.clearScreen(new CharColor(backgroundColor, BLACK));
  } // clearScreen

  public static void clearEol(int x, int y) {
    Toolkit.printString(blanks.substring(0, getScreenWidth() - x), x, y, currentColors);
  } // clearEol

  public static String readLine(int x, int y, String prompt) {
    int xpl = x + prompt.length();
    Toolkit.printString(prompt + blanks.substring(0, getScreenWidth() - xpl), x, y, currentColors);
    StringBuilder sb = new StringBuilder();
    char ch = (char) Toolkit.readCharacter().getCode();
    while (ch != KEY_ENTER) {
      if (ch == InputChar.KEY_BACKSPACE) { // backspace
        if (sb.length() > 0) sb.deleteCharAt(sb.length() - 1);
        Toolkit.printString(" ", xpl + sb.length() + 2, y, currentColors);
      } else if (ch <= 255) {
        Toolkit.printString(String.valueOf(ch), xpl + sb.length() + 2, y , currentColors);
        sb.append(ch);
      }
      ch = (char) Toolkit.readCharacter().getCode();
    }
    String s = sb.toString();
    return s;
  }

  public static byte readByte(int x, int y, String prompt) {
    String s = readLine(x, y, prompt);
    byte n = 0;
    try {
      n = Byte.parseByte(s.trim());
    }
    catch (NumberFormatException e) {
      if (stopOnErrors) {
        Toolkit.printString("Invalid format", x + prompt.length() + s.length() + 3, y, errorColors);
        System.exit(1);
      }
    }
    return n;
  } // readByte

  public static short readShort(int x, int y, String prompt) {
    String s = readLine(x, y, prompt);
    short n = 0;
    try {
      n = Short.parseShort(s.trim());
    }
    catch (NumberFormatException e) {
      if (stopOnErrors) {
        Toolkit.printString("Invalid format", x + prompt.length() + s.length() + 3, y, errorColors);
        System.exit(1);
      }
    }
    return n;
  } // readShort


  public static int readInt(int x, int y, String prompt) {
    String s = readLine(x, y, prompt);
    int n = 0;
    try {
      n = Integer.parseInt(s.trim());
    }
    catch (NumberFormatException e) {
      if (stopOnErrors) {
        Toolkit.printString("Invalid format", x + prompt.length() + s.length() + 3, y, errorColors);
        System.exit(1);
      }
    }
    return n;
  } // readInt

  public static long readLong(int x, int y, String prompt) {
    String s = readLine(x, y, prompt);
    long n = 0;
    try {
      n = Long.parseLong(s.trim());
    }
    catch (NumberFormatException e) {
      if (stopOnErrors) {
        Toolkit.printString("Invalid format", x + prompt.length() + s.length() + 3, y, errorColors);
        System.exit(1);
      }
    }
    return n;
  } // readLong

  public static float readFloat(int x, int y, String prompt) {
    String s = readLine(x, y, prompt);
    float n = 0.0F;
    try {
      n = Float.parseFloat(s.trim());
    }
    catch (NumberFormatException e) {
      if (stopOnErrors) {
        Toolkit.printString("Invalid format", x + prompt.length() + s.length() + 3, y, errorColors);
        System.exit(1);
      }
    }
    return n;
  } // readFloat

  public static double readDouble(int x, int y, String prompt) {
    String s = readLine(x, y, prompt);
    double n = 0.0;
    try {
      n = Double.parseDouble(s.trim());
    }
    catch (NumberFormatException e) {
      if (stopOnErrors) {
        Toolkit.printString("Invalid format", x + prompt.length() + s.length() + 3, y, errorColors);
        System.exit(1);
      }
    }
    return n;
  } // readDouble

  public static boolean readBoolean(int x, int y, String prompt) {
    String s = readLine(x, y, prompt);
    return Boolean.parseBoolean(s.trim());
  } // readBoolean

  public static char readChar(int x, int y, String prompt) {
    write(x, y, prompt);
    char ch = (char) Toolkit.readCharacter().getCode();
    write(x + prompt.length() + 2, y, ch);
    return ch;
  } // readChar

  public static int readKey(int x, int y, String prompt) {
    write(x, y, prompt);
    int k = Toolkit.readCharacter().getCode();
    write(x + prompt.length() + 2, y, k);
    return k;
  } // readKey

  public static final int KEY_ENTER     = 10;
  public static final int KEY_ESCAPE    = 27;
  public static final int KEY_DOWN      = /* InputChar.KEY_DOWN;       */ 258;
  public static final int KEY_UP        = /* InputChar.KEY_UP;         */ 259;
  public static final int KEY_LEFT      = /* InputChar.KEY_LEFT;       */ 260;
  public static final int KEY_RIGHT     = /* InputChar.KEY_RIGHT;      */ 261;
  public static final int KEY_HOME      = /* InputChar.KEY_HOME;       */ 262;
  public static final int KEY_BACKSPACE = /* InputChar.KEY_BACKSPACE;  */ 263;
  public static final int KEY_F1        = /* InputChar.KEY_F1;         */ 265;
  public static final int KEY_F2        = /* InputChar.KEY_F2;         */ 266;
  public static final int KEY_F3        = /* InputChar.KEY_F3;         */ 267;
  public static final int KEY_F4        = /* InputChar.KEY_F4;         */ 268;
  public static final int KEY_F5        = /* InputChar.KEY_F5;         */ 269;
  public static final int KEY_F6        = /* InputChar.KEY_F6;         */ 270;
  public static final int KEY_F7        = /* InputChar.KEY_F7;         */ 271;
  public static final int KEY_F8        = /* InputChar.KEY_F8;         */ 272;
  public static final int KEY_F9        = /* InputChar.KEY_F9;         */ 273;
  public static final int KEY_F10       = /* InputChar.KEY_F10;        */ 274;
  public static final int KEY_F11       = /* InputChar.KEY_F11;        */ 275;
  public static final int KEY_F12       = /* InputChar.KEY_F12;        */ 276;
  public static final int KEY_DELETE    = /* InputChar.KEY_DC;         */ 330;
  public static final int KEY_INSERT    = /* InputChar.KEY_IC;         */ 331;
  public static final int KEY_PAGEDOWN  = /* InputChar.KEY_NPAGE;      */ 338;
  public static final int KEY_PAGEUP    = /* InputChar.KEY_PPAGE;      */ 339;
  public static final int KEY_PRINT     = /* InputChar.KEY_PRINT;      */ 346;
  public static final int KEY_END       = /* InputChar.KEY_END;        */ 360;

  public static int getKey() {
    return Toolkit.readCharacter().getCode();
  } // getKey()

  public static void write(int x, int y, String s) {
    Toolkit.printString(s, x, y, currentColors);
  } // write

  public static void write(int x, int y, long o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, int o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, short o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, byte o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, double o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, float o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, boolean o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, char o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, char[] o) {
    Toolkit.printString(String.valueOf(o), x, y, currentColors);
  } // write

  public static void write(int x, int y, Object o) {
    Toolkit.printString(o.toString(), x, y, currentColors);
  } // write

  public static void drawRectangle(int x, int y, int width, int height) {
    Toolkit.drawRectangle(x, y, width, height, currentColors);
  } // drawRectangle

  public static void drawHorizontalLine(int x, int y, int x2) {
    Toolkit.drawHorizontalLine(x, y, x2, currentColors);
  } // drawHorizontalLine

  public static void drawVerticalLine(int x, int y, int y2) {
    Toolkit.drawVerticalLine(x, y, y2, currentColors);
  } // drawHorizontalLine

  public static void main(String[] args) {

    // test suite
/*
    Screen.init();
    Screen.ignoreErrors();
    Screen.write(5, 5, "(((**************************************((((((((((((((((((((((((((((((");
    String s = Screen.readLine(12, 12, "Name please");
    String t = Screen.readLine(6, 6, "Name please");
    Screen.clearEol(20, 5);
    Screen.write(10, 10, s);
*/

/*
    Screen.write(11, 11, 345);
    Screen.write(13, 13, Screen.readByte(12, 12, "Byte"));
*/
/*
    Screen.write(15, 15, Screen.readBoolean(14, 14, "Boolean"));
    Screen.write(17, 17, Screen.readDouble(16, 16, "Double"));
    Screen.invertColors();
    Screen.write(19, 19, Screen.readChar(18, 18, "Char"));
    Screen.write(21, 21, Screen.readKey(20, 20, "Key"));
    Screen.drawHorizontalLine(4, 4, 60);
    Screen.drawVerticalLine(4, 4, 60);
    Screen.drawRectangle(10, 10, 15, 12);
*/
/*
    int j = 2;
    for (int k = 1; k <=30; k++) {
      Screen.write(2, j++, "hello pat " + k);
      Screen.setForegroundColor((short) (k % 8));
    }
    Screen.setBackgroundColor(YELLOW);
    Screen.write(2, j++, "hello pat " + RED);
    Screen.setForegroundColor(GREEN);
    Screen.write(2, j++, "hello pat " + GREEN);
    Screen.setForegroundColor(YELLOW);
    Screen.write(2, j++, "hello pat " + YELLOW);
    Screen.setForegroundColor(BLUE);
    Screen.write(2, j++, "hello pat " + BLUE);
    Screen.setForegroundColor(MAGENTA);
    Screen.write(2, j++, "hello pat " + MAGENTA);
    Screen.setForegroundColor(CYAN);
    Screen.write(2, j++, "hello pat " + CYAN);
    Screen.setForegroundColor(WHITE);
    Screen.write(2, j++, "hello pat " + WHITE);
    Screen.clearScreen();
*/

  } // main

// } // Screen

}

