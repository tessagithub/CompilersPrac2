using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace GraphicsLib {    // 2015/06/18

// Code in these two classes was mainly developed by Peter Wentworth // (p.wentworth@ru.ac.za),
// for which I am very grateful.

// These classes provide a basic facility for displaying graphical output in a "window" from
// a console application.  The code can doubtless be improved, and suggestions are welcomed.

// Surprisingly, I was not able to find anything like this made available anywhere else
// on the Internet when I trawled it in June 2015!
//
// P.D. Terry (p.terry@ru.ac.za)

// ============================================================================== Class GWindow

  class GWindow : Form {
    Bitmap canvas;
    SolidBrush brush = new SolidBrush(Color.Green);
    Pen pen          = new Pen(Color.Blue, 2);
    Font font        = new Font("Arial", 10, FontStyle.Regular);

    // A semaphore to tell if we're ready for action.
    AutoResetEvent windowIsReady;

    internal GWindow(AutoResetEvent windowIsReady, int width, int height) {
      InitializeComponent();
      this.ClientSize = new Size(width, height);

      // Save the semaphore we need to signal.
      this.windowIsReady = windowIsReady;

      // Wait for the window to be shown for the remaining bits of initializion.
      this.Shown += new System.EventHandler(this.ShowForm);
    } // GWindow.Constructor

    private void ShowForm(object sender, EventArgs e) {
      canvas = new Bitmap(this.ClientSize.Width, this.ClientSize.Height,
                          System.Drawing.Imaging.PixelFormat.Format32bppArgb);
      Graphics g = Graphics.FromImage(canvas);
      g.Clear(Color.LightBlue);
      pbMain.Image = canvas;
      // Announce to the world that we're ready for action!
      windowIsReady.Set();
    } // GWindow.ShowForm

    internal void SetPenColor(Color c) {
      this.pen.Color = c;
    } // GWindow.SetPenColor

    internal void SetPenWidth(int w) {
      this.pen.Width = w;
    } // GWindow.SetPen.Width

    internal void SetBrushColor(Color color) {
      this.brush.Color = color;
    } // GWindow.SetBrushColor

    internal void SetTextFont(Font font) {
      this.font = font;
    } // GWindow.SetTextFont

    internal void Clear() {
      Graphics g = Graphics.FromImage(canvas);
      g.Clear(Color.LightBlue);
      pbMain.Refresh();
    } // GWindow.Clear

    internal void Clear(Color c) {
      Graphics g = Graphics.FromImage(canvas);
      g.Clear(c);
      pbMain.Refresh();
    } // GWindow.Clear

    internal void DrawLine(int x1, int y1, int x2, int y2) {
      Graphics g = Graphics.FromImage(canvas);
      g.DrawLine(pen, x1, y1, x2, y2);
      pbMain.Refresh();
    } // GWindow.DrawLine

    internal void DrawRectangle(int x1, int y1, int width, int height) {
      Graphics g = Graphics.FromImage(canvas);
      g.DrawRectangle(pen, x1, y1, width, height);
      pbMain.Refresh();
    } // GWindow.DrawRectangle

    internal void DrawEllipse(int x1, int y1, int width, int height) {
      Graphics g = Graphics.FromImage(canvas);
      g.DrawEllipse(pen, x1, y1, width, height);
      pbMain.Refresh();
    } // GWindow.DrawEllipse

    internal void FillRectangle(int x1, int y1, int width, int height) {
      Graphics g = Graphics.FromImage(canvas);
      g.FillRectangle(brush, x1, y1, width, height);
      pbMain.Refresh();
    } // GWindow.FillRectangle

    internal void FillEllipse(int x1, int y1, int width, int height) {
      Graphics g = Graphics.FromImage(canvas);
      g.FillEllipse(brush, x1, y1, width, height);
      pbMain.Refresh();
    } // GWindow.FillEllipse

    internal void DrawString(string str, Font font, Brush brush, int x1, int y1) {
      Graphics g = Graphics.FromImage(canvas);
      g.DrawString(str, font, brush, x1, y1);
      pbMain.Refresh();
    } // GWindow.DrawString

    internal void DrawString(string str, int x1, int y1) {
      Graphics g = Graphics.FromImage(canvas);
      g.DrawString(str, font, brush, x1, y1);
      pbMain.Refresh();
    } // GWindow.DrawString

    /// <summary>
    /// Required designer variable.
    /// </summary>

    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>

    protected override void Dispose(bool disposing) {
      if (disposing && (components != null)) {
        components.Dispose();
      }
      base.Dispose(disposing);
    } // GWindow.Dispose

    #region Windows Form Designer generated code - careful!

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>

    private void InitializeComponent() {
      this.pbMain = new System.Windows.Forms.PictureBox();

      ((System.ComponentModel.ISupportInitialize)(this.pbMain)).BeginInit();

      this.SuspendLayout();
      //
      // pbMain
      //
      this.pbMain.Dock     = System.Windows.Forms.DockStyle.Fill;
      this.pbMain.Location = new System.Drawing.Point(0, 0);

  // The commented-out lines were generated from Visual Studio but seem not to be relevant.  In
  // keeping with the philosophy of "keep it as simple as you can but no simpler" they remain
  // in place just in case they prove to  be needed because of some oversight.  2015/06/17

  //    this.pbMain.Name     = "pbMain";
  //    this.pbMain.Size     = new System.Drawing.Size(284, 262);
  //    this.pbMain.TabIndex = 0;
  //    this.pbMain.TabStop  = false;
      //
      // GWindow
      //
  //    this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
  //    this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
  //    this.ClientSize          = new System.Drawing.Size(284, 262);
      this.Controls.Add(this.pbMain);
      this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
  //    this.Name                = "GWindow";
      this.Text                = "Graphics Window";

      ((System.ComponentModel.ISupportInitialize)(this.pbMain)).EndInit();

      this.ResumeLayout(false);
    } // GWindow.InitializeComponent

    #endregion

    private System.Windows.Forms.PictureBox pbMain;

  } // class GWindow

  // ============================================================================== Class GraphicsWindow

  /// This is a shim that "wraps" the real window.  By embedding it, we can
  /// ensure that the client cannot call any window methods we don't want to give them
  /// access to.  The wrapper takes responsibility for creating and managing the thread
  /// that pumps the window, and it ensures that any calls to the primitives are delegated
  /// to the thread that owns the window.
  /// Code initially prototyped by Peter Wentworth; augmented by Pat Terry.  2015/06/17

  public class GraphicsWindow {

    private GWindow theRealWindow;
    Thread ownerThread;
    private double      // Turtle initial location, direction and pen setting
      direction = 0.0,
      turtleX   = 0.0,
      turtleY   = 0.0,
      homeX     = 0.0,
      homeY     = 0.0;
    private bool
      penDown   = true;

    private int
      Width     = 0,    // Canvas dimensions - over-ridden
      Height    = 0;


    // Delegates are needed for .NET 3.5 compiler

    delegate void VOID  ();
    delegate void COLOR (Color c);
    delegate void IIII  (int a, int b, int c, int d);
    delegate void SFBII (string s, Font f, Brush b, int x, int y);
    delegate void SII   (string s, int x, int y);

    // A semaphore, initially false, set true only when the window is ready for client requests.

    AutoResetEvent windowIsReady = new AutoResetEvent(false);

    public GraphicsWindow(int Width, int Height) {
      theRealWindow = new GWindow(windowIsReady, Width, Height);

      ownerThread = new Thread(WhatToRun);      // Create a thread to "message pump" the new window
      ownerThread.IsBackground = true;
      ownerThread.Start();
      this.Width  = Width;
      this.Height = Height;
      this.turtleX = this.homeX = Width  / 2.0; // Turtle is at the centre of the drawing space
      this.turtleY = this.homeY = Height / 2.0;
      windowIsReady.WaitOne();                  // Wait for the window to tell us when it is ready.
    } // GraphicsWindow.Constructor

    private void WhatToRun() {
      Application.Run(theRealWindow);
    } // GraphicsWindow.WhatToRun

    public void Close() {
      if (theRealWindow.IsDisposed) return;
      //  theRealWindow.Invoke(new Action(theRealWindow.Close)); // 4.5
      theRealWindow.Invoke(new VOID(theRealWindow.Close));
    } // GraphicsWindow.Close

    public void Clear() {
      if (theRealWindow.IsDisposed) return;
      //  theRealWindow.Invoke(new Action(theRealWindow.Clear)); // 4.5
      theRealWindow.Invoke(new VOID(theRealWindow.Clear));
    } // GraphicsWindow.Clear()

    public void Clear(Color c) {
      if (theRealWindow.IsDisposed) return;
      //  theRealWindow.Invoke(new Action<Color>(theRealWindow.Clear), c); // 4.5
      theRealWindow.Invoke(new COLOR(theRealWindow.Clear), c);
    } // GraphicsWindow.Clear(c)

    public void DrawLine(int x1, int y1, int x2, int y2) {
      if (theRealWindow.IsDisposed) return;
      // theRealWindow.Invoke(new Action<int, int, int, int>(theRealWindow.DrawLine), x1, y1, x2, y2);  // 4.5
      theRealWindow.Invoke(new IIII(theRealWindow.DrawLine), x1, y1, x2, y2);
    } // GraphicsWindow.DrawLine

    public void DrawRectangle(int x1, int y1, int width, int height) {
      if (theRealWindow.IsDisposed) return;
      // theRealWindow.Invoke(new Action<int, int, int, int>(theRealWindow.DrawRectangle), x1, y1, width, height);  // 4.5
      theRealWindow.Invoke(new IIII(theRealWindow.DrawRectangle), x1, y1, width, height);
    } // GraphicsWindow.DrawRectangle

    public void DrawEllipse(int x1, int y1, int width, int height) {
      if (theRealWindow.IsDisposed) return;
      // theRealWindow.Invoke(new Action<int, int, int, int>(theRealWindow.DrawEllipse), x1, y1, width, height); // 4.5
      theRealWindow.Invoke(new IIII(theRealWindow.DrawEllipse), x1, y1, width, height);
    } // GraphicsWindow.DrawEllipse

    public void FillRectangle(int x1, int y1, int width, int height) {
      if (theRealWindow.IsDisposed) return;
      // theRealWindow.Invoke(new Action<int, int, int, int>(theRealWindow.FillRectangle), x1, y1, width, height); // 4.5
      theRealWindow.Invoke(new IIII(theRealWindow.FillRectangle), x1, y1, width, height);
    } // GraphicsWindow.FillRectangle

    public void FillEllipse(int x1, int y1, int width, int height) {
      if (theRealWindow.IsDisposed) return;
      // theRealWindow.Invoke(new Action<int, int, int, int>(theRealWindow.FillEllipse), x1, y1, width, height); // 4.5
      theRealWindow.Invoke(new IIII(theRealWindow.FillEllipse), x1, y1, width, height);
    } // GraphicsWindow.FillEllipse

    public void DrawString(string str, Font font, Brush brush, int x1, int y1) {
      if (theRealWindow.IsDisposed) return;
      // theRealWindow.Invoke(new Action<string, Font, Brush, int, int>(theRealWindow.DrawString), str, font, brush, x1, y1); // 4.5
      theRealWindow.Invoke(new SFBII(theRealWindow.DrawString), str, font, brush, x1, y1);
    } // GraphicsWindow.DrawString

    public void DrawString(string str, int x1, int y1) {
      if (theRealWindow.IsDisposed) return;
      // theRealWindow.Invoke(new Action<string, int, int>(theRealWindow.DrawString), str, x1, y1); // 4.5
      theRealWindow.Invoke(new SII(theRealWindow.DrawString), str, x1, y1);
    } // GraphicsWindow.DrawString

    public void SetPenColor(Color c) {
      theRealWindow.SetPenColor(c);
    } // GraphicsWindow.SetPenColor

    public void SetPenWidth(int w) {
      theRealWindow.SetPenWidth(w);
    } // GraphicsWindow.SetPen.Width

    public void SetBrushColor(Color color) {
      theRealWindow.SetBrushColor(color);
    } // GraphicsWindow.SetBrushColor

    public void SetTextFont(Font font) {
      theRealWindow.SetTextFont(font);
    } // GraphicsWindow.SetTextFont

    // TurtleGraphics ===============================================

    public void Home() {
      this.turtleX = homeX;
      this.turtleY = homeY;
      this.direction = 0.0;
    } // GraphicsWindow.Home

    public void PenUp() {
      this.penDown = false;
    } // GraphicsWindow.PenUp

    public void PenDown() {
      this.penDown = true;
    } // GraphicsWindow.PenDown

    public void TurnLeft(double degrees) {
      this.direction -= degrees;
    } // GraphicsWindow.TurnLeft

    public void TurnRight(double degrees) {
      this.direction += degrees;
    } // GraphicsWindow.TurnRight

    public void Forward(double distance) {
      double rad  = 0.017453292 * direction;
      double newX = (turtleX + distance * Math.Cos(rad));
      double newY = (turtleY + distance * Math.Sin(rad));
      if (penDown) DrawLine((int) Math.Round(turtleX), (int) Math.Round(turtleY),
                            (int) Math.Round(newX),    (int) Math.Round(newY));
      this.turtleX = newX;
      this.turtleY = newY;
      // Console.WriteLine(newX + "  " + newY + " " + direction);   // debug
    } // GraphicsWindow.Forward

  } // class GraphicsWindow

} // namespace
