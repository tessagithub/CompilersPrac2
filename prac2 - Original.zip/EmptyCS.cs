// (Nearly) Empty program
// P.D. Terry,  Rhodes University, 2017

using Library;

class empty {

  static public void Main(string[] args) {
  } // Main

} // empty
