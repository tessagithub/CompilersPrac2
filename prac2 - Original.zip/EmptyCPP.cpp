// (Nearly) Empty program
// P.D. Terry,  Rhodes University, 2017

#include "misc.h"       // Any difference if you delete this?

  int main() {
  } // main
